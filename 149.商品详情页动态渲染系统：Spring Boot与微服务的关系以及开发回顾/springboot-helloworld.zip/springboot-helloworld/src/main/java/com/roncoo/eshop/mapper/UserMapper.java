package com.roncoo.eshop.mapper;

public interface UserMapper {

}
